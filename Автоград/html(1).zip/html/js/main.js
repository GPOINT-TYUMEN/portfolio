$(document).ready(function(){
    $('.auto__text').addClass("hiddenopacity").viewportChecker({
    	classToAdd: 'visibleopacity animated fadeInUp',
    	offset: 100,
    	callbackFunction: function(elem) {
    		setTimeout(function () {
    			$('.auto__img').delay(1800).addClass("visibleopacity animated fadeInUp");
    		}, 1000);
    	}
    });

    $('#nav').onePageNav({
	    currentClass: 'active',
	    changeHash: false,
	    scrollSpeed: 750,
	    scrollThreshold: 0.5,
	    filter: '',
	    easing: 'swing'
	});
});
