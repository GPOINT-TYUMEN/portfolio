$(document).ready(function() {
	$(".tabs").tabs();

	$('input, select').styler({
		fileBrowse: "Upload photo"
	});
});
